package com.jama.clock;
import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;
public class A extends Activity{
protected void onCreate(Bundle s){
super.onCreate(s);
int i=getIntent().getIntExtra("appWidgetId",0);
Intent r=new Intent().putExtra("appWidgetId",i);
setResult(0,r);
SharedPreferences p=getSharedPreferences("p",0);
int d=(int)(16*getResources().getDisplayMetrics().density);
LinearLayout l=new LinearLayout(this);
l.setOrientation(1);l.setGravity(1);l.setPadding(d,d,d,d);
TextView t=new TextView(this);
t.setTypeface(getResources().getFont(R.font.clock));
t.setText("12:34");t.setTextSize(72);
int c=p.getInt("c"+i,-1);
t.setTextColor(c);
P q=new P(this,c);
final int[] k={c};
q.r=x->{k[0]=x;t.setTextColor(x);};
Switch w=new Switch(this);
w.setText("24h");w.setChecked(p.getBoolean("h"+i,true));
Button b=new Button(this);
b.setText("OK");
b.setOnClickListener(v->{
p.edit().putInt("c"+i,k[0]).putBoolean("h"+i,w.isChecked()).apply();
W.u(this,AppWidgetManager.getInstance(this),i);
setResult(-1,r);finish();});
l.addView(t);l.addView(q);l.addView(w);l.addView(b);
ScrollView z=new ScrollView(this);
z.addView(l);
setContentView(z);
}}
