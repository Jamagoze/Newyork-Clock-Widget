package com.jama.clock;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.WallpaperManager;
import android.app.WallpaperColors;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;
public class A extends Activity{
int d;
void a(LinearLayout l,int[] cs,View.OnClickListener k){
LinearLayout r=new LinearLayout(this);
r.setWeightSum(13);
for(int c:cs){
View v=new View(this);
v.setBackgroundColor(c);v.setTag(c);v.setOnClickListener(k);
LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,d*44,1);
q.setMargins(d,d,d,d);
r.addView(v,q);}
l.addView(r);}
protected void onCreate(Bundle s){
super.onCreate(s);
int i=getIntent().getIntExtra("appWidgetId",0);
Intent n=new Intent().putExtra("appWidgetId",i);
setResult(0,n);
d=(int)getResources().getDisplayMetrics().density;
View.OnClickListener k=v->{
SharedPreferences p=getSharedPreferences("p",0);
p.edit().putInt("c"+i,(Integer)v.getTag()).apply();
W.all(this);
setResult(-1,n);
if(Build.VERSION.SDK_INT>=31&&!getSystemService(AlarmManager.class).canScheduleExactAlarms()&&!p.getBoolean("x",false)){
p.edit().putBoolean("x",true).apply();
startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));}
finish();};
LinearLayout l=new LinearLayout(this);
l.setOrientation(1);l.setPadding(d*16,d*16,d*16,d*16);
WallpaperColors w=getSystemService(WallpaperManager.class).getWallpaperColors(1);
if(w!=null){
ArrayList<Integer> x=new ArrayList<>();
x.add(w.getPrimaryColor().toArgb());
if(w.getSecondaryColor()!=null)x.add(w.getSecondaryColor().toArgb());
if(w.getTertiaryColor()!=null)x.add(w.getTertiaryColor().toArgb());
int[] z=new int[x.size()];
for(int j=0;j<z.length;j++)z[j]=x.get(j);
a(l,z,k);}
int[] T={0,10,50,100,200,300,400,500,600,700,800,900,1000};
for(String m:new String[]{"accent1","accent2","accent3","neutral1","neutral2"}){
int[] cs=new int[13];
boolean o=true;
for(int j=0;j<13;j++){
int id=getResources().getIdentifier("system_"+m+"_"+T[j],"color","android");
if(id==0)o=false;else cs[j]=getResources().getColor(id,null);}
if(o)a(l,cs,k);}
ScrollView z=new ScrollView(this);
z.addView(l);
setContentView(z);
}}
