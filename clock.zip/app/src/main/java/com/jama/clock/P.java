package com.jama.clock;
import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import java.util.function.IntConsumer;
public class P extends View{
float[] v=new float[3];int a,m;IntConsumer r;float d,g,b,h;
Paint p=new Paint(1);
static int[] H={-65536,-256,-16711936,-16711681,-16776961,-65281,-65536};
P(Context c,int o){
super(c);
d=c.getResources().getDisplayMetrics().density;
g=12*d;b=32*d;
a=Color.alpha(o);
Color.colorToHSV(o,v);
}
protected void onMeasure(int w,int x){
int y=Math.min(MeasureSpec.getSize(w),(int)(360*d));
setMeasuredDimension(y,(int)(y*.75f+2*g+2*b));
}
int c(){return Color.HSVToColor(a,v);}
void o(Canvas k,float x,float y){
p.setShader(null);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2*d);
p.setColor(-1);k.drawCircle(x,y,10*d,p);
p.setColor(-16777216);k.drawCircle(x,y,12*d,p);
p.setStyle(Paint.Style.FILL);
}
protected void onDraw(Canvas k){
float W=getWidth();h=W*.75f;
float y=h+g,z=y+b+g;
Shader.TileMode t=Shader.TileMode.CLAMP;
int f=Color.HSVToColor(new float[]{v[0],1,1}),q=Color.HSVToColor(v);
p.setShader(new LinearGradient(0,0,W,0,-1,f,t));k.drawRect(0,0,W,h,p);
p.setShader(new LinearGradient(0,0,0,h,0,-16777216,t));k.drawRect(0,0,W,h,p);
p.setShader(new LinearGradient(0,0,W,0,H,null,t));k.drawRect(0,y,W,y+b,p);
p.setShader(null);p.setColor(-8355712);k.drawRect(0,z,W,z+b,p);
p.setShader(new LinearGradient(0,0,W,0,q&0xFFFFFF,q,t));k.drawRect(0,z,W,z+b,p);
o(k,v[1]*W,(1-v[2])*h);
o(k,v[0]/360*W,y+b/2);
o(k,a/255f*W,z+b/2);
}
public boolean onTouchEvent(MotionEvent e){
float W=getWidth(),x=Math.max(0,Math.min(e.getX(),W)),y=e.getY();
if(e.getAction()==0){
getParent().requestDisallowInterceptTouchEvent(true);
m=y<h+g/2?0:y<h+g+b+g/2?1:2;
}
if(m==0){v[1]=x/W;v[2]=1-Math.max(0,Math.min(y/h,1));}
else if(m==1)v[0]=x/W*359.99f;
else a=Math.round(x/W*255);
invalidate();
r.accept(c());
return true;
}}
