package com.jama.clock;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.*;
import android.os.Build;
import android.os.Bundle;
import android.widget.RemoteViews;
import java.util.Calendar;
public class W extends AppWidgetProvider{
static Typeface f;
static PendingIntent q(Context c){return PendingIntent.getBroadcast(c,0,new Intent(c,W.class).setAction("t"),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
static void all(Context c){
AppWidgetManager m=AppWidgetManager.getInstance(c);
int[] a=m.getAppWidgetIds(new ComponentName(c,W.class));
if(a.length==0)return;
for(int i:a)u(c,m,i);
AlarmManager s=c.getSystemService(AlarmManager.class);
long t=(System.currentTimeMillis()/60000+1)*60000;
if(Build.VERSION.SDK_INT<31||s.canScheduleExactAlarms())s.setExact(1,t,q(c));else s.set(1,t,q(c));}
static void u(Context c,AppWidgetManager m,int i){
Bundle o=m.getAppWidgetOptions(i);
boolean l=c.getResources().getConfiguration().orientation==2;
float d=c.getResources().getDisplayMetrics().density;
int w=o.getInt(l?"appWidgetMaxWidth":"appWidgetMinWidth"),h=o.getInt(l?"appWidgetMinHeight":"appWidgetMaxHeight");
if(w<1||h<1){w=110;h=40;}
float s=Math.min(1,(float)Math.sqrt(800000/(w*d*h*d)));
int pw=(int)(w*d*s),ph=(int)(h*d*s);
if(f==null)f=c.getResources().getFont(R.font.clock);
Paint t=new Paint(1);
t.setTypeface(f);t.setTextAlign(Paint.Align.CENTER);
t.setColor(c.getSharedPreferences("p",0).getInt("c"+i,-1));
t.setTextSize(100);
Rect r=new Rect();
t.getTextBounds("0",0,1,r);
t.setTextSize(100*Math.min(pw*.96f/t.measureText("00:00"),ph*.9f/r.height()));
t.getTextBounds("0",0,1,r);
Calendar a=Calendar.getInstance();
int H=a.get(Calendar.HOUR),M=a.get(Calendar.MINUTE);
Bitmap b=Bitmap.createBitmap(pw,ph,Bitmap.Config.ARGB_8888);
new Canvas(b).drawText((H==0?12:H)+":"+(M<10?"0":"")+M,pw/2f,ph/2f-r.exactCenterY(),t);
RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.w);
v.setImageViewBitmap(R.id.i,b);
v.setOnClickPendingIntent(R.id.i,PendingIntent.getActivity(c,i,new Intent(c,A.class).putExtra("appWidgetId",i),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
m.updateAppWidget(i,v);}
public void onReceive(Context c,Intent e){
super.onReceive(c,e);
if(!"android.appwidget.action.APPWIDGET_UPDATE".equals(e.getAction()))all(c);}
public void onUpdate(Context c,AppWidgetManager m,int[] a){all(c);}
public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int i,Bundle o){u(c,m,i);}
public void onDisabled(Context c){c.getSystemService(AlarmManager.class).cancel(q(c));}
public void onDeleted(Context c,int[] a){SharedPreferences.Editor e=c.getSharedPreferences("p",0).edit();for(int i:a)e.remove("c"+i);e.apply();}
}
