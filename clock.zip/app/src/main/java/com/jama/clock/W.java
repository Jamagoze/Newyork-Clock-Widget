package com.jama.clock;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
public class W extends AppWidgetProvider{
static void u(Context c,AppWidgetManager m,int i){
SharedPreferences p=c.getSharedPreferences("p",0);
RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.w);
String f=p.getBoolean("h"+i,true)?"HH:mm":"h:mm";
v.setTextColor(R.id.t,p.getInt("c"+i,-1));
v.setCharSequence(R.id.t,"setFormat12Hour",f);
v.setCharSequence(R.id.t,"setFormat24Hour",f);
v.setOnClickPendingIntent(R.id.t,PendingIntent.getActivity(c,i,new Intent(c,A.class).putExtra("appWidgetId",i),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
m.updateAppWidget(i,v);}
public void onUpdate(Context c,AppWidgetManager m,int[] a){for(int i:a)u(c,m,i);}
public void onDeleted(Context c,int[] a){SharedPreferences.Editor e=c.getSharedPreferences("p",0).edit();for(int i:a)e.remove("c"+i).remove("h"+i);e.apply();}
}
